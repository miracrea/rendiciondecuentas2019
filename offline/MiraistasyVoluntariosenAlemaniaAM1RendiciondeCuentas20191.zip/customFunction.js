function customTrackPageView(action, msg) {
  //alert("action: " + action + ", msg: " + msg);
}